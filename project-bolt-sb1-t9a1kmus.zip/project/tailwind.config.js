/** @type {import('tailwindcss').Config} */
export default {
  content: ["./index.html", "./src/**/*.{js,ts,jsx,tsx}"],
  theme: {
    extend: {
      colors: {
        cream: {
          50: "#fdfbf7",
          100: "#f8f3ea",
          200: "#efe5d4",
          300: "#e2d3bb",
          400: "#d0bd9b",
          500: "#bda580",
          600: "#a88e64",
          700: "#8a7150",
          800: "#6f5b40",
          900: "#5a4a34",
        },
        ink: {
          50: "#f6f6f5",
          100: "#e7e7e5",
          200: "#d3d3d0",
          300: "#b5b5b0",
          400: "#8e8e87",
          500: "#72726b",
          600: "#5b5b54",
          700: "#494944",
          800: "#3d3d39",
          900: "#1a1a18",
          950: "#0d0d0c",
        },
        accent: {
          50: "#fdf6f0",
          100: "#faeadb",
          200: "#f4d2b5",
          300: "#ecb384",
          400: "#e2915a",
          500: "#d97438",
          600: "#cb5a2a",
          700: "#a8441f",
          800: "#873720",
          900: "#6e2e1d",
          950: "#3b160c",
        },
      },
      fontFamily: {
        display: ["'Playfair Display'", "Georgia", "serif"],
        sans: ["'Inter'", "system-ui", "sans-serif"],
      },
      fontSize: {
        "display-xl": ["clamp(2.5rem, 8vw, 6rem)", { lineHeight: "1.05", letterSpacing: "-0.03em" }],
        "display-lg": ["clamp(2rem, 6vw, 4.5rem)", { lineHeight: "1.08", letterSpacing: "-0.02em" }],
        "display-md": ["clamp(1.5rem, 4vw, 3rem)", { lineHeight: "1.1", letterSpacing: "-0.01em" }],
      },
      animation: {
        "float-slow": "float 8s ease-in-out infinite",
        "float-slower": "float 12s ease-in-out infinite",
        "gradient-shift": "gradientShift 8s ease infinite",
        shimmer: "shimmer 2.5s linear infinite",
      },
      keyframes: {
        float: {
          "0%, 100%": { transform: "translateY(0)" },
          "50%": { transform: "translateY(-20px)" },
        },
        gradientShift: {
          "0%, 100%": { backgroundPosition: "0% 50%" },
          "50%": { backgroundPosition: "100% 50%" },
        },
        shimmer: {
          "0%": { backgroundPosition: "-200% 0" },
          "100%": { backgroundPosition: "200% 0" },
        },
      },
    },
  },
  plugins: [],
};
