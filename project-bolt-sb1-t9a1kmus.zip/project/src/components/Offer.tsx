import { offerContent } from "../data/business";
import { Reveal } from "./Reveal";
import { MagneticButton } from "./MagneticButton";

export function Offer() {
  return (
    <section className="px-6 py-16 sm:px-8 lg:px-12">
      <div className="mx-auto max-w-7xl">
        <Reveal>
          <div className="relative overflow-hidden rounded-[2.5rem] bg-ink-900 px-8 py-16 sm:px-16 lg:px-24 lg:py-20">
            {/* Animated gradient background */}
            <div
              className="absolute inset-0 opacity-30"
              style={{
                background:
                  "linear-gradient(120deg, #cb5a2a, #8a7150, #cb5a2a, #d97438)",
                backgroundSize: "300% 300%",
                animation: "gradientShift 8s ease infinite",
              }}
            />

            {/* Floating blobs */}
            <div className="pointer-events-none absolute -left-10 -top-10 h-48 w-48 rounded-full bg-accent-500/20 blur-3xl animate-float-slow" />
            <div className="pointer-events-none absolute -bottom-10 right-10 h-56 w-56 rounded-full bg-accent-400/15 blur-3xl animate-float-slower" />

            {/* Grain overlay */}
            <div className="grain pointer-events-none absolute inset-0 opacity-20" />

            <div className="relative z-10 text-center">
              <Reveal>
                <span className="inline-block rounded-full border border-cream-50/20 bg-cream-50/10 px-4 py-1.5 text-xs font-semibold uppercase tracking-[0.15em] text-cream-50 backdrop-blur-sm">
                  {offerContent.badge}
                </span>
              </Reveal>
              <Reveal delay={0.1}>
                <h2 className="mt-6 font-display text-display-lg font-medium text-cream-50">
                  {offerContent.title}
                </h2>
              </Reveal>
              <Reveal delay={0.2}>
                <p className="mx-auto mt-5 max-w-md text-lg leading-relaxed text-cream-200/80">
                  {offerContent.description}
                </p>
              </Reveal>
              <Reveal delay={0.3}>
                <div className="mt-10 flex justify-center">
                  <MagneticButton href={offerContent.ctaHref} variant="primary" arrow>
                    {offerContent.cta}
                  </MagneticButton>
                </div>
              </Reveal>
            </div>
          </div>
        </Reveal>
      </div>
    </section>
  );
}
