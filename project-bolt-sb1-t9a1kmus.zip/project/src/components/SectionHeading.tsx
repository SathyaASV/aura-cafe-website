import { type ReactNode } from "react";
import { Reveal } from "./Reveal";

interface SectionHeadingProps {
  eyebrow?: string;
  title: string;
  subtitle?: string;
  align?: "left" | "center";
  className?: string;
  light?: boolean;
}

export function SectionHeading({
  eyebrow,
  title,
  subtitle,
  align = "left",
  className = "",
  light = false,
}: SectionHeadingProps) {
  return (
    <div
      className={`${align === "center" ? "mx-auto text-center" : "text-left"} ${className}`}
    >
      {eyebrow && (
        <Reveal>
          <span
            className={`mb-4 inline-block text-xs font-semibold uppercase tracking-[0.2em] ${
              light ? "text-accent-300" : "text-accent-600"
            }`}
          >
            {eyebrow}
          </span>
        </Reveal>
      )}
      <Reveal delay={0.1}>
        <h2
          className={`font-display text-display-md font-medium ${
            light ? "text-cream-50" : "text-ink-900"
          }`}
        >
          {title}
        </h2>
      </Reveal>
      {subtitle && (
        <Reveal delay={0.2}>
          <p
            className={`mt-5 max-w-xl text-lg leading-relaxed ${
              align === "center" ? "mx-auto" : ""
            } ${light ? "text-cream-200/80" : "text-ink-600"}`}
          >
            {subtitle}
          </p>
        </Reveal>
      )}
    </div>
  );
}

interface SectionProps {
  children: ReactNode;
  id?: string;
  className?: string;
}

export function Section({ children, id, className = "" }: SectionProps) {
  return (
    <section id={id} className={`relative px-6 py-24 sm:px-8 lg:px-12 lg:py-32 ${className}`}>
      <div className="mx-auto max-w-7xl">{children}</div>
    </section>
  );
}
