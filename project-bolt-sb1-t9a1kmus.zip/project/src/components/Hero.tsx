import { useEffect, useState } from "react";
import { Coffee, Star, MapPin, Clock } from "lucide-react";
import { heroContent, trustItems, business } from "../data/business";
import { MagneticButton } from "./MagneticButton";

const iconMap: Record<string, typeof Coffee> = {
  Coffee,
  Star,
  MapPin,
  Clock,
};

export function Hero() {
  const [mounted, setMounted] = useState(false);
  const [scrollY, setScrollY] = useState(0);

  useEffect(() => {
    const t = setTimeout(() => setMounted(true), 100);
    const onScroll = () => setScrollY(window.scrollY);
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => {
      clearTimeout(t);
      window.removeEventListener("scroll", onScroll);
    };
  }, []);

  return (
    <section id="home" className="relative min-h-[100svh] overflow-hidden">
      {/* Background image with reveal + parallax */}
      <div className="absolute inset-0">
        <div
          className="absolute inset-0 transition-transform duration-[1.8s] ease-[cubic-bezier(0.22,1,0.36,1)]"
          style={{
            transform: `scale(${mounted ? 1 : 1.08}) translateY(${scrollY * 0.15}px)`,
          }}
        >
          <img
            src={heroContent.image}
            alt="AURA Café interior"
            className="h-full w-full object-cover"
            fetchPriority="high"
          />
        </div>
        {/* Gradient overlays */}
        <div className="absolute inset-0 bg-gradient-to-b from-ink-950/40 via-ink-950/30 to-ink-950/70" />
        <div className="absolute inset-0 bg-gradient-to-r from-ink-950/60 via-transparent to-transparent" />
      </div>

      {/* Floating decorative blobs */}
      <div className="pointer-events-none absolute -left-20 top-1/4 h-72 w-72 rounded-full bg-accent-500/20 blur-3xl animate-float-slow" />
      <div className="pointer-events-none absolute right-10 top-1/3 h-48 w-48 rounded-full bg-accent-300/10 blur-3xl animate-float-slower" />

      {/* Content */}
      <div className="relative z-10 mx-auto flex min-h-[100svh] max-w-7xl flex-col justify-center px-6 sm:px-8 lg:px-12">
        {/* Location indicator */}
        <div
          className="mb-8 flex items-center gap-2"
          style={{
            opacity: mounted ? 1 : 0,
            transform: mounted ? "translateY(0)" : "translateY(20px)",
            transition: "all 0.8s cubic-bezier(0.22,1,0.36,1) 0.2s",
          }}
        >
          <span className="relative flex h-2.5 w-2.5">
            <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-green-400 opacity-75" />
            <span className="relative inline-flex h-2.5 w-2.5 rounded-full bg-green-500" />
          </span>
          <span className="text-sm font-medium tracking-wide text-cream-100/90">
            {heroContent.locationLabel}
          </span>
        </div>

        {/* Headline */}
        <h1 className="font-display text-display-xl font-medium text-cream-50">
          <span className="block overflow-hidden">
            <span
              className="inline-block"
              style={{
                opacity: mounted ? 1 : 0,
                transform: mounted ? "translateY(0)" : "translateY(100%)",
                filter: mounted ? "blur(0px)" : "blur(10px)",
                transition: "all 1s cubic-bezier(0.22,1,0.36,1) 0.4s",
              }}
            >
              {heroContent.line1}
            </span>
          </span>
          <span className="block overflow-hidden">
            <span
              className="inline-block italic text-accent-300"
              style={{
                opacity: mounted ? 1 : 0,
                transform: mounted ? "translateY(0)" : "translateY(100%)",
                filter: mounted ? "blur(0px)" : "blur(10px)",
                transition: "all 1s cubic-bezier(0.22,1,0.36,1) 0.6s",
              }}
            >
              {heroContent.line2}
            </span>
          </span>
        </h1>

        {/* Description */}
        <p
          className="mt-8 max-w-md text-lg leading-relaxed text-cream-100/80"
          style={{
            opacity: mounted ? 1 : 0,
            transform: mounted ? "translateY(0)" : "translateY(20px)",
            filter: mounted ? "blur(0px)" : "blur(8px)",
            transition: "all 0.9s cubic-bezier(0.22,1,0.36,1) 0.8s",
          }}
        >
          {heroContent.description}
        </p>

        {/* CTAs */}
        <div
          className="mt-10 flex flex-wrap items-center gap-4"
          style={{
            opacity: mounted ? 1 : 0,
            transform: mounted ? "translateY(0)" : "translateY(20px)",
            transition: "all 0.9s cubic-bezier(0.22,1,0.36,1) 1s",
          }}
        >
          <MagneticButton href={heroContent.primaryCtaHref} variant="primary" arrow>
            {heroContent.primaryCta}
          </MagneticButton>
          <MagneticButton href={heroContent.secondaryCtaHref} variant="ghost" className="!text-cream-50 !border-cream-50/20 hover:!bg-cream-50/10 hover:!border-cream-50/40">
            {heroContent.secondaryCta}
          </MagneticButton>
        </div>

        {/* Scroll indicator */}
        <div
          className="absolute bottom-8 left-1/2 -translate-x-1/2"
          style={{
            opacity: mounted ? 1 : 0,
            transition: "opacity 1s ease 1.4s",
          }}
        >
          <div className="flex h-10 w-6 items-start justify-center rounded-full border-2 border-cream-50/30 p-1.5">
            <div className="h-2 w-1 animate-bounce rounded-full bg-cream-50/60" />
          </div>
        </div>
      </div>

      {/* Trust bar */}
      <div className="relative z-10 border-t border-cream-50/10 bg-ink-950/40 backdrop-blur-md">
        <div className="mx-auto grid max-w-7xl grid-cols-2 gap-px px-6 sm:px-8 lg:grid-cols-4 lg:px-12">
          {trustItems.map((item, i) => {
            const Icon = iconMap[item.icon] ?? Coffee;
            return (
              <div
                key={item.title}
                className="flex items-center gap-3 py-5 lg:justify-center lg:py-6"
                style={{
                  opacity: mounted ? 1 : 0,
                  transform: mounted ? "translateY(0)" : "translateY(20px)",
                  transition: `all 0.7s cubic-bezier(0.22,1,0.36,1) ${1.2 + i * 0.12}s`,
                }}
              >
                <Icon className="h-5 w-5 shrink-0 text-accent-400" strokeWidth={1.5} />
                <div>
                  <p className="text-sm font-semibold text-cream-50">{item.title}</p>
                  <p className="text-xs text-cream-200/60">{item.subtitle}</p>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
}
