import { finalCtaContent } from "../data/business";
import { Reveal } from "./Reveal";
import { MagneticButton } from "./MagneticButton";

export function FinalCta() {
  return (
    <section className="relative overflow-hidden px-6 py-24 sm:px-8 lg:px-12 lg:py-32">
      {/* Animated background */}
      <div className="absolute inset-0 -z-10">
        <div
          className="absolute inset-0 opacity-[0.07]"
          style={{
            background:
              "linear-gradient(120deg, #d97438, #bda580, #cb5a2a, #d97438)",
            backgroundSize: "300% 300%",
            animation: "gradientShift 10s ease infinite",
          }}
        />
        <div className="pointer-events-none absolute left-1/4 top-0 h-72 w-72 rounded-full bg-accent-500/10 blur-3xl animate-float-slow" />
        <div className="pointer-events-none absolute right-1/4 bottom-0 h-64 w-64 rounded-full bg-accent-400/8 blur-3xl animate-float-slower" />
      </div>

      <div className="mx-auto max-w-4xl text-center">
        <Reveal>
          <h2 className="font-display text-display-lg font-medium text-ink-900">
            {finalCtaContent.heading}
          </h2>
        </Reveal>
        <Reveal delay={0.15}>
          <p className="mx-auto mt-6 max-w-md text-lg leading-relaxed text-ink-600">
            {finalCtaContent.description}
          </p>
        </Reveal>
        <Reveal delay={0.3}>
          <div className="mt-10 flex justify-center">
            <MagneticButton href={finalCtaContent.ctaHref} variant="primary" arrow>
              {finalCtaContent.cta}
            </MagneticButton>
          </div>
        </Reveal>
      </div>
    </section>
  );
}
