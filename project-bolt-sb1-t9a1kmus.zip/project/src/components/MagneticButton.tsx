import { useRef, type ReactNode, type MouseEvent } from "react";

interface MagneticButtonProps {
  children: ReactNode;
  href?: string;
  onClick?: () => void;
  variant?: "primary" | "secondary" | "ghost";
  className?: string;
  arrow?: boolean;
}

export function MagneticButton({
  children,
  href = "#",
  onClick,
  variant = "primary",
  className = "",
  arrow = false,
}: MagneticButtonProps) {
  const ref = useRef<HTMLAnchorElement>(null);
  const isTouch = useRef(false);

  const handleMove = (e: MouseEvent<HTMLAnchorElement>) => {
    if (isTouch.current || !ref.current) return;
    const rect = ref.current.getBoundingClientRect();
    const x = e.clientX - rect.left - rect.width / 2;
    const y = e.clientY - rect.top - rect.height / 2;
    const strength = 0.25;
    ref.current.style.transform = `translate(${x * strength}px, ${y * strength}px)`;
  };

  const handleLeave = () => {
    if (!ref.current) return;
    ref.current.style.transform = "translate(0, 0)";
  };

  const base =
    "group relative inline-flex items-center gap-2 rounded-full px-7 py-3.5 text-sm font-medium tracking-wide transition-all duration-300 will-change-transform";

  const variants: Record<string, string> = {
    primary:
      "bg-accent-500 text-white hover:bg-accent-600 shadow-lg shadow-accent-500/25 hover:shadow-xl hover:shadow-accent-500/30",
    secondary:
      "bg-ink-900 text-cream-50 hover:bg-ink-800 shadow-lg shadow-ink-900/20",
    ghost:
      "bg-transparent text-ink-900 border border-ink-900/15 hover:border-ink-900/30 hover:bg-ink-900/5",
  };

  return (
    <a
      ref={ref}
      href={href}
      onClick={onClick}
      onMouseMove={handleMove}
      onMouseLeave={handleLeave}
      onTouchStart={() => (isTouch.current = true)}
      className={`${base} ${variants[variant]} ${className}`}
      style={{ transition: "transform 0.3s cubic-bezier(0.22,1,0.36,1), background-color 0.3s, box-shadow 0.3s" }}
    >
      <span className="relative z-10">{children}</span>
      {arrow && (
        <svg
          className="relative z-10 h-4 w-4 transition-transform duration-300 group-hover:translate-x-1"
          fill="none"
          viewBox="0 0 24 24"
          stroke="currentColor"
          strokeWidth={2}
        >
          <path strokeLinecap="round" strokeLinejoin="round" d="M13 7l5 5m0 0l-5 5m5-5H6" />
        </svg>
      )}
      {variant === "primary" && (
        <span className="pointer-events-none absolute inset-0 rounded-full opacity-0 transition-opacity duration-500 group-hover:opacity-100"
          style={{
            background: "linear-gradient(120deg, transparent 30%, rgba(255,255,255,0.2) 50%, transparent 70%)",
            backgroundSize: "200% 100%",
            animation: "shimmer 2.5s linear infinite",
          }}
        />
      )}
    </a>
  );
}
