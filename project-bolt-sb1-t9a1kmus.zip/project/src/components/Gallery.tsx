import { galleryImages } from "../data/business";
import { Reveal } from "./Reveal";
import { Section, SectionHeading } from "./SectionHeading";
import { Plus } from "lucide-react";

// Column spans for masonry effect on desktop
const spans = [
  "lg:row-span-2",
  "",
  "lg:row-span-2",
  "",
  "",
  "lg:row-span-2",
  "",
  "",
];

export function Gallery() {
  return (
    <Section id="gallery">
      <SectionHeading
        eyebrow="Gallery"
        title="A look inside."
        subtitle="Moments from the café — the coffee, the light, the people."
        align="center"
        className="mb-16"
      />
      <div className="grid grid-cols-2 gap-3 sm:gap-4 lg:grid-cols-4 lg:auto-rows-[200px]">
        {galleryImages.map((img, i) => (
          <Reveal
            key={img.src}
            delay={i * 0.06}
            className={`group relative overflow-hidden rounded-2xl ${spans[i % spans.length]}`}
          >
            <div className="h-full w-full">
              <img
                src={img.src}
                alt={img.alt}
                className="h-full min-h-[180px] w-full object-cover transition-transform duration-700 ease-out group-hover:scale-110"
                loading="lazy"
              />
            </div>
            {/* Overlay */}
            <div className="absolute inset-0 flex items-center justify-center bg-ink-950/40 opacity-0 transition-opacity duration-500 group-hover:opacity-100">
              <div className="flex h-12 w-12 items-center justify-center rounded-full border border-cream-50/30 bg-cream-50/10 backdrop-blur-sm">
                <Plus className="h-5 w-5 text-cream-50" strokeWidth={1.5} />
              </div>
            </div>
          </Reveal>
        ))}
      </div>
    </Section>
  );
}
