import { experienceContent } from "../data/business";
import { Reveal } from "./Reveal";

export function Experience() {
  return (
    <section className="relative overflow-hidden">
      {/* Background image */}
      <div className="absolute inset-0">
        <img
          src={experienceContent.image}
          alt="Café experience"
          className="h-full w-full object-cover"
          loading="lazy"
        />
        <div className="absolute inset-0 bg-ink-950/75" />
        <div className="absolute inset-0 bg-gradient-to-b from-ink-950/60 via-ink-950/70 to-ink-950/90" />
      </div>

      {/* Floating blob */}
      <div className="pointer-events-none absolute right-1/4 top-20 h-64 w-64 rounded-full bg-accent-500/10 blur-3xl animate-float-slow" />

      <div className="relative z-10 px-6 py-28 sm:px-8 lg:px-12 lg:py-36">
        <div className="mx-auto max-w-5xl text-center">
          <Reveal>
            <span className="mb-4 inline-block text-xs font-semibold uppercase tracking-[0.2em] text-accent-400">
              The Experience
            </span>
          </Reveal>
          <Reveal delay={0.1}>
            <h2 className="font-display text-display-lg font-medium text-cream-50">
              {experienceContent.heading}
            </h2>
          </Reveal>
          <Reveal delay={0.2}>
            <p className="mx-auto mt-6 max-w-xl text-lg leading-relaxed text-cream-200/70">
              {experienceContent.subtitle}
            </p>
          </Reveal>
        </div>

        {/* Feature cards */}
        <div className="mx-auto mt-20 grid max-w-5xl gap-6 sm:grid-cols-3">
          {experienceContent.features.map((feature, i) => (
            <Reveal key={feature.number} delay={i * 0.15}>
              <div className="group relative rounded-3xl border border-cream-50/10 bg-cream-50/5 p-8 backdrop-blur-sm transition-all duration-500 hover:border-cream-50/20 hover:bg-cream-50/10">
                <span className="font-display text-5xl font-semibold text-accent-400/80 transition-colors group-hover:text-accent-400">
                  {feature.number}
                </span>
                <h3 className="mt-4 font-display text-xl font-semibold text-cream-50">
                  {feature.title}
                </h3>
                <p className="mt-2 text-sm leading-relaxed text-cream-200/60">
                  {feature.description}
                </p>
                <div className="mt-6 h-px w-full bg-gradient-to-r from-accent-500/40 to-transparent" />
              </div>
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  );
}
