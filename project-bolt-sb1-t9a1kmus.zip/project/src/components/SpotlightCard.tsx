import { useRef, type ReactNode, type MouseEvent } from "react";

interface SpotlightCardProps {
  children: ReactNode;
  className?: string;
  spotlightColor?: string;
}

/**
 * Card with a cursor-following spotlight effect.
 * Uses CSS variables for pointer position — no React re-renders on mouse move.
 */
export function SpotlightCard({
  children,
  className = "",
  spotlightColor = "rgba(217, 116, 56, 0.15)",
}: SpotlightCardProps) {
  const ref = useRef<HTMLDivElement>(null);

  const handleMove = (e: MouseEvent<HTMLDivElement>) => {
    const el = ref.current;
    if (!el) return;
    const rect = el.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const y = e.clientY - rect.top;
    el.style.setProperty("--spot-x", `${x}px`);
    el.style.setProperty("--spot-y", `${y}px`);
  };

  return (
    <div
      ref={ref}
      onMouseMove={handleMove}
      className={`group relative overflow-hidden rounded-3xl ${className}`}
      style={{
        ["--spot-x" as string]: "50%",
        ["--spot-y" as string]: "50%",
      }}
    >
      {/* Spotlight overlay */}
      <div
        className="pointer-events-none absolute inset-0 z-10 opacity-0 transition-opacity duration-500 group-hover:opacity-100"
        style={{
          background: `radial-gradient(400px circle at var(--spot-x) var(--spot-y), ${spotlightColor}, transparent 60%)`,
        }}
      />
      {children}
    </div>
  );
}
