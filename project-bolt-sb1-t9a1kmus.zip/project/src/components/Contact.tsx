import { contactContent, business } from "../data/business";
import { Reveal } from "./Reveal";
import { Section } from "./SectionHeading";
import { MapPin, Phone, Clock, Navigation } from "lucide-react";

export function Contact() {
  return (
    <Section id="contact">
      <div className="grid gap-12 lg:grid-cols-2 lg:gap-20">
        {/* Left: info */}
        <div>
          <Reveal>
            <span className="mb-4 inline-block text-xs font-semibold uppercase tracking-[0.2em] text-accent-600">
              Contact
            </span>
          </Reveal>
          <Reveal delay={0.1}>
            <h2 className="font-display text-display-md font-medium text-ink-900">
              {contactContent.heading}
            </h2>
          </Reveal>
          <Reveal delay={0.2}>
            <p className="mt-5 text-lg leading-relaxed text-ink-600">
              {contactContent.subtitle}
            </p>
          </Reveal>

          <div className="mt-10 space-y-6">
            <Reveal delay={0.3}>
              <div className="flex items-start gap-4">
                <div className="flex h-11 w-11 shrink-0 items-center justify-center rounded-full bg-accent-500/10">
                  <MapPin className="h-5 w-5 text-accent-600" strokeWidth={1.5} />
                </div>
                <div>
                  <p className="text-xs font-semibold uppercase tracking-wider text-ink-400">Address</p>
                  <p className="mt-1 text-base text-ink-800">{business.address}</p>
                </div>
              </div>
            </Reveal>

            <Reveal delay={0.4}>
              <div className="flex items-start gap-4">
                <div className="flex h-11 w-11 shrink-0 items-center justify-center rounded-full bg-accent-500/10">
                  <Phone className="h-5 w-5 text-accent-600" strokeWidth={1.5} />
                </div>
                <div>
                  <p className="text-xs font-semibold uppercase tracking-wider text-ink-400">Phone</p>
                  <a href={business.phoneHref} className="mt-1 block text-base text-ink-800 transition-colors hover:text-accent-600">
                    {business.phone}
                  </a>
                </div>
              </div>
            </Reveal>

            <Reveal delay={0.5}>
              <div className="flex items-start gap-4">
                <div className="flex h-11 w-11 shrink-0 items-center justify-center rounded-full bg-accent-500/10">
                  <Clock className="h-5 w-5 text-accent-600" strokeWidth={1.5} />
                </div>
                <div>
                  <p className="text-xs font-semibold uppercase tracking-wider text-ink-400">Hours</p>
                  <p className="mt-1 text-base text-ink-800">{business.hours}</p>
                </div>
              </div>
            </Reveal>
          </div>

          <Reveal delay={0.6}>
            <div className="mt-10 flex flex-wrap gap-4">
              <a
                href={business.mapsHref}
                target="_blank"
                rel="noopener noreferrer"
                className="group inline-flex items-center gap-2 rounded-full bg-ink-900 px-6 py-3 text-sm font-medium text-cream-50 transition-all duration-300 hover:bg-accent-500 hover:shadow-lg hover:shadow-accent-500/25"
              >
                <Navigation className="h-4 w-4" strokeWidth={2} />
                Get Directions
              </a>
              <a
                href={business.phoneHref}
                className="group inline-flex items-center gap-2 rounded-full border border-ink-900/15 px-6 py-3 text-sm font-medium text-ink-900 transition-all duration-300 hover:border-ink-900/30 hover:bg-ink-900/5"
              >
                <Phone className="h-4 w-4" strokeWidth={2} />
                Call Us
              </a>
            </div>
          </Reveal>
        </div>

        {/* Right: stylized map */}
        <Reveal delay={0.3} className="relative">
          <div className="relative h-full min-h-[400px] overflow-hidden rounded-[2rem] border border-ink-900/5 bg-cream-100">
            {/* Stylized map placeholder */}
            <div className="absolute inset-0 bg-gradient-to-br from-cream-200/50 to-cream-300/30">
              {/* Grid lines mimicking streets */}
              <svg className="absolute inset-0 h-full w-full opacity-20" xmlns="http://www.w3.org/2000/svg">
                <defs>
                  <pattern id="grid" width="60" height="60" patternUnits="userSpaceOnUse">
                    <path d="M 60 0 L 0 0 0 60" fill="none" stroke="#5a4a34" strokeWidth="0.5" />
                  </pattern>
                </defs>
                <rect width="100%" height="100%" fill="url(#grid)" />
              </svg>
              {/* Diagonal "road" */}
              <div className="absolute left-0 top-1/2 h-1 w-full -rotate-12 bg-accent-500/30" />
              <div className="absolute left-1/4 top-0 h-full w-1 rotate-6 bg-ink-300/40" />
            </div>

            {/* Location pin */}
            <div className="absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2">
              <div className="relative flex flex-col items-center">
                <div className="absolute -inset-8 animate-ping rounded-full bg-accent-500/20" />
                <div className="relative flex h-14 w-14 items-center justify-center rounded-full bg-accent-500 shadow-xl shadow-accent-500/40">
                  <MapPin className="h-7 w-7 text-white" strokeWidth={1.5} fill="currentColor" />
                </div>
                <div className="mt-3 rounded-full bg-ink-900 px-4 py-2 text-xs font-medium text-cream-50 shadow-lg">
                  {business.name}
                </div>
              </div>
            </div>

            {/* Overlay info */}
            <div className="absolute bottom-4 left-4 right-4 flex items-center justify-between rounded-2xl bg-cream-50/90 p-4 backdrop-blur-md">
              <div>
                <p className="text-sm font-semibold text-ink-900">{business.address}</p>
                <p className="text-xs text-ink-500">{business.hours}</p>
              </div>
              <a
                href={business.mapsHref}
                target="_blank"
                rel="noopener noreferrer"
                className="rounded-full bg-accent-500 px-4 py-2 text-xs font-medium text-white transition-colors hover:bg-accent-600"
              >
                Open Map
              </a>
            </div>
          </div>
        </Reveal>
      </div>
    </Section>
  );
}
