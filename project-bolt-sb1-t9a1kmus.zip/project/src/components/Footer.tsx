import { business, footerContent } from "../data/business";
import { Instagram, Facebook, Twitter } from "lucide-react";

export function Footer() {
  return (
    <footer className="relative overflow-hidden bg-ink-950 px-6 pt-20 pb-10 sm:px-8 lg:px-12">
      {/* Grain */}
      <div className="grain pointer-events-none absolute inset-0 opacity-10" />

      <div className="relative z-10 mx-auto max-w-7xl">
        <div className="grid gap-12 lg:grid-cols-[1.5fr_1fr_1fr_1fr]">
          {/* Brand */}
          <div>
            <p className="font-display text-3xl font-semibold text-cream-50">
              {business.shortName}
              <span className="text-accent-500">.</span>
            </p>
            <p className="mt-3 max-w-xs text-sm leading-relaxed text-cream-200/60">
              {business.tagline}
            </p>
            <div className="mt-6 flex gap-3">
              <a
                href={business.social.instagram}
                target="_blank"
                rel="noopener noreferrer"
                className="flex h-10 w-10 items-center justify-center rounded-full border border-cream-50/10 text-cream-200/60 transition-all duration-300 hover:border-accent-500/50 hover:bg-accent-500/10 hover:text-accent-400"
                aria-label="Instagram"
              >
                <Instagram size={18} />
              </a>
              <a
                href={business.social.facebook}
                target="_blank"
                rel="noopener noreferrer"
                className="flex h-10 w-10 items-center justify-center rounded-full border border-cream-50/10 text-cream-200/60 transition-all duration-300 hover:border-accent-500/50 hover:bg-accent-500/10 hover:text-accent-400"
                aria-label="Facebook"
              >
                <Facebook size={18} />
              </a>
              <a
                href={business.social.twitter}
                target="_blank"
                rel="noopener noreferrer"
                className="flex h-10 w-10 items-center justify-center rounded-full border border-cream-50/10 text-cream-200/60 transition-all duration-300 hover:border-accent-500/50 hover:bg-accent-500/10 hover:text-accent-400"
                aria-label="Twitter"
              >
                <Twitter size={18} />
              </a>
            </div>
          </div>

          {/* Link columns */}
          {footerContent.columns.map((col) => (
            <div key={col.title}>
              <h4 className="text-xs font-semibold uppercase tracking-[0.15em] text-cream-200/40">
                {col.title}
              </h4>
              <ul className="mt-4 space-y-3">
                {col.links.map((link) => (
                  <li key={link.label}>
                    <a
                      href={link.href}
                      className="text-sm text-cream-200/70 transition-colors hover:text-accent-400"
                    >
                      {link.label}
                    </a>
                  </li>
                ))}
              </ul>
            </div>
          ))}

          {/* Hours */}
          <div>
            <h4 className="text-xs font-semibold uppercase tracking-[0.15em] text-cream-200/40">
              Hours
            </h4>
            <p className="mt-4 text-sm leading-relaxed text-cream-200/70">
              {business.hours}
            </p>
            <p className="mt-2 text-xs text-cream-200/40">Open every day</p>
          </div>
        </div>

        {/* Bottom bar */}
        <div className="mt-16 flex flex-col items-center justify-between gap-4 border-t border-cream-50/10 pt-8 sm:flex-row">
          <p className="text-xs text-cream-200/40">
            © {new Date().getFullYear()} {business.name}. All rights reserved.
          </p>
          <p className="text-xs text-cream-200/40">
            Crafted with care for great local businesses.
          </p>
        </div>
      </div>
    </footer>
  );
}
