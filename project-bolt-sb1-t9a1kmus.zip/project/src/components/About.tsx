import { useEffect, useRef, useState } from "react";
import { aboutContent } from "../data/business";
import { Reveal } from "./Reveal";
import { Section } from "./SectionHeading";

export function About() {
  const [scrollY, setScrollY] = useState(0);
  const sectionRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const onScroll = () => {
      if (!sectionRef.current) return;
      const rect = sectionRef.current.getBoundingClientRect();
      const offset = rect.top + rect.height / 2 - window.innerHeight / 2;
      setScrollY(-offset);
    };
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  return (
    <Section id="about">
      <div ref={sectionRef} className="grid items-center gap-12 lg:grid-cols-2 lg:gap-20">
        {/* Image with parallax */}
        <Reveal y={40} className="relative">
          <div className="relative overflow-hidden rounded-[2rem]">
            <div
              className="aspect-[4/5] w-full"
              style={{
                transform: `translateY(${scrollY * 0.06}px) scale(1.1)`,
              }}
            >
              <img
                src={aboutContent.image}
                alt="AURA Café interior"
                className="h-full w-full object-cover"
                loading="lazy"
              />
            </div>
            <div className="absolute inset-0 bg-gradient-to-t from-ink-950/20 to-transparent" />
          </div>

          {/* Floating badge */}
          <div className="absolute -bottom-6 -right-4 rounded-2xl bg-cream-50 p-5 shadow-xl lg:-right-8">
            <p className="font-display text-3xl font-semibold text-accent-600">10+</p>
            <p className="text-xs font-medium uppercase tracking-wider text-ink-500">
              Years of
              <br />
              crafting coffee
            </p>
          </div>
        </Reveal>

        {/* Text */}
        <div>
          <Reveal>
            <span className="mb-4 inline-block text-xs font-semibold uppercase tracking-[0.2em] text-accent-600">
              Our Story
            </span>
          </Reveal>
          <Reveal delay={0.1}>
            <h2 className="font-display text-display-md font-medium text-ink-900">
              {aboutContent.heading}
            </h2>
          </Reveal>
          <Reveal delay={0.2}>
            <p className="mt-6 text-lg leading-relaxed text-ink-600">
              {aboutContent.paragraph1}
            </p>
          </Reveal>
          <Reveal delay={0.3}>
            <p className="mt-4 text-base leading-relaxed text-ink-500">
              {aboutContent.paragraph2}
            </p>
          </Reveal>
          <Reveal delay={0.4}>
            <a
              href={aboutContent.ctaHref}
              className="group mt-8 inline-flex items-center gap-2 text-sm font-semibold text-accent-600 transition-colors hover:text-accent-700"
            >
              <span className="link-underline">{aboutContent.cta}</span>
              <svg
                className="h-4 w-4 transition-transform duration-300 group-hover:translate-x-1"
                fill="none"
                viewBox="0 0 24 24"
                stroke="currentColor"
                strokeWidth={2}
              >
                <path strokeLinecap="round" strokeLinejoin="round" d="M13 7l5 5m0 0l-5 5m5-5H6" />
              </svg>
            </a>
          </Reveal>
        </div>
      </div>
    </Section>
  );
}
