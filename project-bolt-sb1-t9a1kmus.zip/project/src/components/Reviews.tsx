import { reviewsContent } from "../data/business";
import { Reveal } from "./Reveal";
import { Section, SectionHeading } from "./SectionHeading";
import { Star, Quote } from "lucide-react";

function AnimatedStars({ count }: { count: number }) {
  return (
    <div className="flex gap-1">
      {Array.from({ length: count }).map((_, i) => (
        <Star
          key={i}
          className="h-4 w-4 fill-accent-500 text-accent-500"
          style={{
            animation: `fadeInScale 0.4s ease ${i * 0.1}s both`,
          }}
        />
      ))}
      <style>{`
        @keyframes fadeInScale {
          from { opacity: 0; transform: scale(0.5); }
          to { opacity: 1; transform: scale(1); }
        }
      `}</style>
    </div>
  );
}

function TestimonialCard({
  review,
  index,
}: {
  review: (typeof reviewsContent.reviews)[number];
  index: number;
}) {
  return (
    <Reveal delay={index * 0.15} className="h-full">
      <div className="gradient-border relative flex h-full flex-col rounded-3xl border border-ink-900/5 bg-cream-50 p-8 shadow-sm transition-all duration-500 hover:shadow-xl hover:shadow-ink-900/8 hover:-translate-y-1">
        <Quote className="h-8 w-8 text-accent-500/30" fill="currentColor" />
        <p className="mt-4 flex-1 text-base leading-relaxed text-ink-700">
          "{review.quote}"
        </p>
        <div className="mt-6 flex items-center justify-between">
          <div>
            <p className="font-display text-lg font-semibold text-ink-900">{review.name}</p>
            <p className="text-xs text-ink-400">{review.role}</p>
          </div>
          <AnimatedStars count={review.rating} />
        </div>
      </div>
    </Reveal>
  );
}

export function Reviews() {
  return (
    <Section id="reviews" className="bg-cream-100/50">
      <SectionHeading
        eyebrow="Reviews"
        title={reviewsContent.heading}
        subtitle={reviewsContent.subtitle}
        align="center"
        className="mb-16"
      />
      <div className="grid gap-6 md:grid-cols-3">
        {reviewsContent.reviews.map((review, i) => (
          <TestimonialCard key={review.name} review={review} index={i} />
        ))}
      </div>
    </Section>
  );
}
