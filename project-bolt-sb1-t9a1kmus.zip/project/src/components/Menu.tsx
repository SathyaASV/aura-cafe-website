import { menuItems, menuHeading, business, type MenuItem } from "../data/business";
import { Reveal } from "./Reveal";
import { Section, SectionHeading } from "./SectionHeading";
import { SpotlightCard } from "./SpotlightCard";

function MenuCard({ item, index }: { item: MenuItem; index: number }) {
  return (
    <Reveal delay={index * 0.1}>
      <SpotlightCard className="border border-ink-900/5 bg-cream-50 shadow-sm transition-all duration-500 hover:shadow-2xl hover:shadow-ink-900/10 hover:-translate-y-1">
        <div className="relative aspect-[4/3] overflow-hidden rounded-t-3xl">
          <img
            src={item.image}
            alt={item.name}
            className="h-full w-full object-cover transition-transform duration-700 ease-out group-hover:scale-110"
            loading="lazy"
          />
          {item.badge && (
            <span className="absolute left-4 top-4 rounded-full bg-ink-900/80 px-3 py-1 text-xs font-medium text-cream-50 backdrop-blur-sm">
              {item.badge}
            </span>
          )}
          <div className="absolute inset-0 bg-gradient-to-t from-ink-950/30 to-transparent opacity-0 transition-opacity duration-500 group-hover:opacity-100" />
        </div>
        <div className="relative z-20 p-6">
          <div className="flex items-start justify-between gap-4">
            <h3 className="font-display text-xl font-semibold text-ink-900">{item.name}</h3>
            <span className="shrink-0 rounded-full bg-accent-500/10 px-3 py-1 text-sm font-semibold text-accent-700">
              {business.currency}{item.price}
            </span>
          </div>
          <p className="mt-2 text-sm leading-relaxed text-ink-500">{item.description}</p>
        </div>
      </SpotlightCard>
    </Reveal>
  );
}

export function Menu() {
  return (
    <Section id="menu" className="bg-cream-100/50">
      <SectionHeading
        eyebrow="Featured Menu"
        title={menuHeading.title}
        subtitle={menuHeading.subtitle}
        align="center"
        className="mb-16"
      />
      <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-4">
        {menuItems.map((item, i) => (
          <MenuCard key={item.name} item={item} index={i} />
        ))}
      </div>
      <div className="mt-12 text-center">
        <Reveal>
          <a
            href="#contact"
            className="group inline-flex items-center gap-2 text-sm font-semibold text-accent-600 transition-colors hover:text-accent-700"
          >
            <span className="link-underline">View Full Menu</span>
            <svg
              className="h-4 w-4 transition-transform duration-300 group-hover:translate-x-1"
              fill="none"
              viewBox="0 0 24 24"
              stroke="currentColor"
              strokeWidth={2}
            >
              <path strokeLinecap="round" strokeLinejoin="round" d="M13 7l5 5m0 0l-5 5m5-5H6" />
            </svg>
          </a>
        </Reveal>
      </div>
    </Section>
  );
}
