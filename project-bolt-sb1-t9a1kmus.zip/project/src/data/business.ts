// ============================================================
// AURA Café — Central Business Configuration
// Change anything here to rebrand the entire website.
// ============================================================

export const business = {
  name: "AURA Café",
  shortName: "AURA",
  tagline: "Good coffee. Better moments.",
  description:
    "Freshly brewed coffee, handcrafted treats, and a space made for slowing down.",
  currency: "₹",

  // Contact
  address: "24 Market Street, Downtown",
  phone: "+91 98765 43210",
  phoneHref: "tel:+919876543210",
  email: "hello@auracafe.in",
  hours: "Mon–Sun: 8:00 AM – 10:00 PM",
  locationLabel: "Downtown • Open Today",

  // Maps
  mapsQuery: "24 Market Street Downtown",
  mapsHref:
    "https://www.google.com/maps/search/?api=1&query=24+Market+Street+Downtown",

  // Social
  social: {
    instagram: "https://instagram.com",
    facebook: "https://facebook.com",
    twitter: "https://twitter.com",
  },
};

export const navLinks = [
  { label: "Home", href: "#home" },
  { label: "About", href: "#about" },
  { label: "Menu", href: "#menu" },
  { label: "Gallery", href: "#gallery" },
  { label: "Reviews", href: "#reviews" },
  { label: "Contact", href: "#contact" },
];

export const heroContent = {
  line1: "Good coffee.",
  line2: "Better moments.",
  description:
    "Freshly brewed coffee, handcrafted treats, and a space made for slowing down.",
  primaryCta: "Explore Menu",
  primaryCtaHref: "#menu",
  secondaryCta: "Visit Us",
  secondaryCtaHref: "#contact",
  locationLabel: business.locationLabel,
  image:
    "https://images.pexels.com/photos/17104305/pexels-photo-17104305.jpeg?auto=compress&cs=tinysrgb&w=1600",
};

export const trustItems = [
  { icon: "Coffee", title: "Freshly Roasted", subtitle: "Every morning" },
  { icon: "Star", title: "4.9 Customer Rating", subtitle: "200+ reviews" },
  { icon: "MapPin", title: "Downtown Location", subtitle: "Easy to find" },
  { icon: "Clock", title: "Open Daily", subtitle: "8 AM – 10 PM" },
];

export const aboutContent = {
  heading: "More than coffee.",
  paragraph1:
    "A neighborhood café built around great coffee, good food, and even better conversations. Every cup is crafted with intention, every plate made with care.",
  paragraph2:
    "From our espresso bar to our kitchen, we believe the best moments happen when you slow down — when the aroma hits before the first sip, when the room hums with quiet warmth.",
  cta: "Discover Our Story",
  ctaHref: "#menu",
  image:
    "https://images.pexels.com/photos/37838325/pexels-photo-37838325.jpeg?auto=compress&cs=tinysrgb&w=1200",
};

export const menuHeading = {
  title: "Made Fresh.",
  subtitle: "Served Beautifully.",
  description:
    "A curated selection of our most-loved drinks and treats, crafted fresh throughout the day.",
};

export interface MenuItem {
  name: string;
  description: string;
  price: string;
  image: string;
  badge?: string;
}

export const menuItems: MenuItem[] = [
  {
    name: "Espresso",
    description: "Bold, rich double shot pulled from house-roasted beans.",
    price: "140",
    image:
      "https://images.pexels.com/photos/15735736/pexels-photo-15735736.jpeg?auto=compress&cs=tinysrgb&w=800",
  },
  {
    name: "Cappuccino",
    description: "Velvety microfoam over a smooth espresso, dusted with cocoa.",
    price: "180",
    image:
      "https://images.pexels.com/photos/28496565/pexels-photo-28496565.jpeg?auto=compress&cs=tinysrgb&w=800",
    badge: "Popular",
  },
  {
    name: "Cold Brew",
    description: "18-hour steeped, slow-dripped, served over hand-cut ice.",
    price: "200",
    image:
      "https://images.pexels.com/photos/13302015/pexels-photo-13302015.jpeg?auto=compress&cs=tinysrgb&w=800",
  },
  {
    name: "Signature Tiramisu",
    description: "Layered mascarpone, espresso-soaked sponge, dark cocoa.",
    price: "260",
    image:
      "https://images.pexels.com/photos/17558644/pexels-photo-17558644.jpeg?auto=compress&cs=tinysrgb&w=800",
    badge: "Chef's Pick",
  },
];

export const offerContent = {
  badge: "Weekend Special",
  title: "Coffee + Dessert",
  description:
    "Get any signature coffee paired with our chef's dessert — the perfect weekend indulgence.",
  cta: "Claim Offer",
  ctaHref: "#contact",
};

export const experienceContent = {
  heading: "Your new favourite corner of the city.",
  subtitle:
    "A space designed for unhurried mornings, quiet afternoons, and evenings that linger.",
  image:
    "https://images.pexels.com/photos/5865209/pexels-photo-5865209.jpeg?auto=compress&cs=tinysrgb&w=1600",
  features: [
    { number: "01", title: "Freshly brewed", description: "Beans roasted in-house, every single week." },
    { number: "02", title: "Handcrafted food", description: "Made-to-order from our daily seasonal menu." },
    { number: "03", title: "Made for moments", description: "A warm, unhurried space to sit and stay." },
  ],
};

export const galleryImages = [
  { src: "https://images.pexels.com/photos/36851643/pexels-photo-36851643.jpeg?auto=compress&cs=tinysrgb&w=800", alt: "Flat white with heart latte art" },
  { src: "https://images.pexels.com/photos/34104248/pexels-photo-34104248.jpeg?auto=compress&cs=tinysrgb&w=800", alt: "Café interior with wooden decor" },
  { src: "https://images.pexels.com/photos/36848520/pexels-photo-36848520.jpeg?auto=compress&cs=tinysrgb&w=800", alt: "Swan latte art from above" },
  { src: "https://images.pexels.com/photos/11406429/pexels-photo-11406429.jpeg?auto=compress&cs=tinysrgb&w=800", alt: "Espresso machine and counter" },
  { src: "https://images.pexels.com/photos/28936789/pexels-photo-28936789.jpeg?auto=compress&cs=tinysrgb&w=800", alt: "Cappuccinos with latte art on wooden tray" },
  { src: "https://images.pexels.com/photos/12149886/pexels-photo-12149886.jpeg?auto=compress&cs=tinysrgb&w=800", alt: "Coffee dispensers in cozy café" },
  { src: "https://images.pexels.com/photos/35107742/pexels-photo-35107742.jpeg?auto=compress&cs=tinysrgb&w=800", alt: "Intricate latte art on patterned table" },
  { src: "https://images.pexels.com/photos/5151354/pexels-photo-5151354.jpeg?auto=compress&cs=tinysrgb&w=800", alt: "Latte art being poured into a cup" },
];

export const reviewsContent = {
  heading: "Loved by the neighbourhood.",
  subtitle: "Real words from the people who make AURA what it is.",
  reviews: [
    {
      quote: "Best cappuccino I've had in the area. The atmosphere is incredible — I keep coming back.",
      name: "Ananya",
      role: "Regular since day one",
      rating: 5,
    },
    {
      quote: "The cold brew is unreal and the tiramisu is the best in the city. A genuinely special place.",
      name: "Rohan",
      role: "Weekend regular",
      rating: 5,
    },
    {
      quote: "I came for the coffee and stayed for the vibe. It feels like the neighbourhood's living room.",
      name: "Meera",
      role: "Works from here daily",
      rating: 5,
    },
  ],
};

export const contactContent = {
  heading: "Come say hello.",
  subtitle: "We'd love to see you. Drop by, or give us a call.",
};

export const finalCtaContent = {
  heading: "Your table is waiting.",
  description: "Drop by for your next coffee break.",
  cta: "Book a Table",
  ctaHref: "#contact",
};

export const footerContent = {
  columns: [
    {
      title: "Explore",
      links: navLinks,
    },
    {
      title: "Visit",
      links: [
        { label: business.address, href: business.mapsHref },
        { label: business.phone, href: business.phoneHref },
        { label: business.email, href: `mailto:${business.email}` },
      ],
    },
  ],
};
